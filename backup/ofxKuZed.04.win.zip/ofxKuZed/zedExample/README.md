#zedExample
This is an example of using ofxKuZed addon for ZED camera.

After starting, it draws left and right RGB images,
depth image and masked image, obtained as left image, 
truncated by depth values using threshold.

Press '-' and '=' to change threshold.

Press '2' to switch to point cloud view. 

Here use mouse for changine view position, angle and scale.

Press '1' to switch back to images view.

Keys:
* '1','2' - select page (images and depth / point cloud)
* '-','=' - adjust threshold

Requirements and installation details see in addon's file ofxKuZed.h

##Compiled binaries
Compiled binaries are here: https://sourceforge.net/projects/ofxkuzed-zedexample/
